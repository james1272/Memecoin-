"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { TextIcon as Telegram, Twitter, Moon, Sun } from "lucide-react"
import dynamic from "next/dynamic"
import MemeGallery from "./meme-gallery"
import Tokenomics from "./tokenomics"
import Roadmap from "./roadmap"
import HowToBuy from "./how-to-buy"
import Team from "./team"
import PriceTickerBanner from "./price-ticker-banner"
import CountdownTimer from "./countdown-timer"
import AnimatedBackground from "./animated-background"
import ParallaxSection from "./parallax-section"
import Chat from "./chat"
import NFTShowcase from "./nft-showcase"
import MiniGame from "./mini-game"
import LanguageSelector from "./language-selector"
import SocialFeed from "./social-feed"
import NewsletterSignup from "./newsletter-signup"
import FAQ from "./faq"

// Dynamically import the 3D background to avoid SSR issues
const DynamicThreeJSBackground = dynamic(() => import("./threejs-background"), { ssr: false })

export default function Home() {
  const [darkMode, setDarkMode] = useState(true)

  useEffect(() => {
    // Check for saved theme preference or use system preference
    const savedTheme = localStorage.getItem("theme")
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches
    setDarkMode(savedTheme === "dark" || (savedTheme === null && prefersDark))
  }, [])

  const toggleDarkMode = () => {
    setDarkMode(!darkMode)
    localStorage.setItem("theme", !darkMode ? "dark" : "light")
  }

  return (
    <div className={`min-h-screen ${darkMode ? "dark" : ""}`}>
      <div className="bg-white dark:bg-[#1a1a1a] text-black dark:text-white relative overflow-hidden transition-colors duration-300">
        <AnimatedBackground />
        <DynamicThreeJSBackground />
        <PriceTickerBanner />

        {/* Navigation */}
        <nav className="bg-gray-100 dark:bg-[#232323] py-4 sticky top-0 z-50">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center">
              <div className="flex space-x-6 text-sm overflow-x-auto">
                <a href="#" className="hover:text-yellow-400">
                  HOME
                </a>
                <a href="#about" className="hover:text-yellow-400">
                  ABOUT
                </a>
                <a href="#tokenomics" className="hover:text-yellow-400">
                  TOKENOMICS
                </a>
                <a href="#roadmap" className="hover:text-yellow-400">
                  ROADMAP
                </a>
                <a href="#how-to-buy" className="hover:text-yellow-400">
                  HOW TO BUY
                </a>
                <a href="#memes" className="hover:text-yellow-400">
                  MEMES
                </a>
                <a href="#team" className="hover:text-yellow-400">
                  TEAM
                </a>
                <a href="#nft" className="hover:text-yellow-400">
                  NFT
                </a>
                <a href="#faq" className="hover:text-yellow-400">
                  FAQ
                </a>
              </div>
              <div className="flex items-center space-x-4">
                <LanguageSelector />
                <Button onClick={toggleDarkMode} variant="ghost" size="icon">
                  {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                </Button>
              </div>
            </div>
          </div>
        </nav>

        <ParallaxSection>
          {/* Hero Section */}
          <div className="container mx-auto px-4 py-12 text-center relative z-10">
            <h1 className="text-5xl md:text-8xl font-bold text-orange-400 mb-12">SADMONKE</h1>

            {/* Logo */}
            <div className="w-64 h-64 mx-auto mb-8 rounded-full overflow-hidden transform hover:scale-105 transition-transform duration-300">
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20250213_101538_181.jpg-X5G3uSVvR5ZuirSTKiV6QDpDR8QLNi.jpeg"
                alt="SadMonke Logo"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Introduction */}
            <div className="max-w-2xl mx-auto space-y-6 mb-12" id="about">
              <h2 className="text-2xl font-bold">Welcome to the SadMonke Movement!</h2>
              <p className="text-gray-700 dark:text-gray-300">
                Imagine a world where cryptocurrency is more than just a digital asset – it's a symbol of unity,
                freedom, and decentralization. Welcome to the SadMonke movement, a groundbreaking initiative that's set
                to disrupt the status quo.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                Backed by cutting-edge "Number Go Up" technology, SadMonke is inspired by the beloved meme that has
                captured the hearts of millions.
              </p>
            </div>

            <CountdownTimer targetDate="2025-04-20T04:20:00" />

            {/* Action Buttons */}
            <div className="flex justify-center space-x-4 flex-wrap gap-4 mb-12">
              <Button className="bg-green-500 hover:bg-green-600 text-white font-bold">BUY SADMONKE NOW</Button>
              <Button className="bg-green-500 hover:bg-green-600 text-white font-bold">SADMONKE STAKING</Button>
              <Button className="bg-green-500 hover:bg-green-600 text-white font-bold">LAUNCH APP</Button>
            </div>

            {/* Community Buttons */}
            <div className="space-y-4 mb-12">
              <Button
                className="w-full max-w-md bg-blue-500 hover:bg-blue-600"
                onClick={() => window.open("https://t.me/Sadmonkeee", "_blank")}
              >
                <Telegram className="mr-2 h-5 w-5" />
                JOIN OUR COMMUNITY
              </Button>

              <Button
                className="w-full max-w-md bg-black hover:bg-gray-900"
                onClick={() => window.open("https://x.com/ItsSadMonke69", "_blank")}
              >
                <Twitter className="mr-2 h-5 w-5" />
                FOLLOW ON X
              </Button>
            </div>
          </div>
        </ParallaxSection>

        <Tokenomics />
        <Roadmap />
        <HowToBuy />
        <MemeGallery />
        <NFTShowcase />
        <Team />
        <MiniGame />
        <FAQ />
        <SocialFeed />
        <NewsletterSignup />
        <Chat />
      </div>
    </div>
  )
}

